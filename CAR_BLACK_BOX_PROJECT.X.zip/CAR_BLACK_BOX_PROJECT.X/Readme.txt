****************************************************************************************************************************************************

Author: Sharan A
Date : 30/01/2025
Project Title: Car Black Box ? Event Data Recorder

****************************************************************************************************************************************************

Files Included:
1.  adc.c, adc.h
2.  black_box.h
3.  clcd.c, clcd.h
4.  clear_log.c
5.  digital_keypad.c, digital_keypad.h
6.  display_main_menu.c
7.  download_log.c
8.  DS1307.c, DS1307.h
9.  eeprom.c, eeprom.h
10. External_EEPROM.c, External_EEPROM.h
11. external_eeprom_store.c
12. I2C.c, I2C.h
13. main.c
14. matrix_keypad.c, matrix_keypad.h
15. set_time.c
16. UART.c, UART.h
17. view_dashboard.c
18. view_log.c


Overview : 

The Car Black Box is an event data recorder (EDR) designed to capture critical driving events. 
It logs information such as speed, engine temperature, fuel consumption, and trip distance. 
The system enhances vehicle monitoring, promotes safe driving, and can be extended into an IoT-based solution.

Features : 

Event Logging       : Records gear shifts, speed.
Real-Time Monitoring: Captures events even while logs are being viewed.
Dashboard Display   : Shows current time, speed, and latest events.

Requirements : 

Hardware: PIC18F4580 microcontroller, EEPROM (AT24C02), RTC (DS1307), CLCD screen, tactile buttons.
Software: Embedded C programming, I2C and CAN protocols.